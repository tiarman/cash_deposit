<x-mail::message>

    # Welcome
   ## You are selected for our next step.

{{--    ## Time: {{ $mailData->created_at->format('h:i A') }}--}}
{{--    ## Date: {{ $mailData->created_at->format('F d, Y') }}--}}
{{--# Introduction--}}

{{--The body of your message.--}}

{{--<x-mail::button :url="''">--}}
{{--##You are shortlisted--}}
{{--</x-mail::button>--}}

### Thanks For Selected,<br>
{{--{{ config('app.name') }}--}}
</x-mail::message>
