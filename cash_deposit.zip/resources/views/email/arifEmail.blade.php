<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>{{ $testDetails['title'] }}</h1>
    <p>{{ $testDetails['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>