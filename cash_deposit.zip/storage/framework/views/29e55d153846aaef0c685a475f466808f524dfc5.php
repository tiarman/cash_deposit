
<?php $__env->startSection('content'); ?>
    <div class="card ">
        <div class="card-body">
            <div class="row">
                <div class="col-12 text-center"><a href="<?php echo e(route('home')); ?>" class="logo logo-admin">
                        <img src="<?php echo e(asset('assets/text-logo.png')); ?>" height="80" alt="logo">
                    </a></div>
            </div>
            <div class="pl-3 pr-3 pb-3">
                <div class="row">
                    <div class="col-12 text-center">
                        <h6 class="m-2">Please Reset your password:</h6>
                        <hr>
                        <?php if(session()->has('message')): ?>
                            <h6 class="text-success"><?php echo session()->get('message'); ?></h6>
                        <?php endif; ?>
                    </div>
                </div>


                <form class="form-horizontal" action="<?php echo e(route('password.reset.store',request('token'))); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e(request('email')); ?>">
                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="d-flex">
                            <input type="password" name="password" id="password" placeholder="Enter Your Password" autocomplete="off"
                                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password')); ?>" required>
                            <span class="mt-1 "><i class="fa fa-regular fa-key icon login-icon"></i></span>
                        </div>

                        <span class="spin"></span>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="password_confirmation">Confirm Password</label>
                        <div class="d-flex">
                            <input type="password" name="password_confirmation" id="password_confirmation" placeholder="Enter Your Password" autocomplete="off"
                                   class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password_confirmation')); ?>" required>
                            <span class="mt-1 "><i class="fa fa-regular fa-key icon login-icon"></i></span>
                        </div>

                        <span class="spin"></span>
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row m-t-20">
                        <div class="col-sm-12 text-right">
                            <button class="btn btn-success w-md waves-effect waves-light" type="submit" name="verify" >Submit</button>

                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/admin/auth/reset-password.blade.php ENDPATH**/ ?>