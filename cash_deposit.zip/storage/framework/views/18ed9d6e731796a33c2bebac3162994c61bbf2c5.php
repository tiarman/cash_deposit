<li class="list-inline-item dropdown notification-list notificationList">
  <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button"
     aria-haspopup="false" aria-expanded="false">
    <i class="ion-ios7-bell noti-icon"></i>
    <span class="badge badge-danger noti-icon-badge unread-notification"><?php echo e($unReadNotification); ?></span>
  </a>
  <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg" style="max-height: 450px;overflow-y: auto">
    <!-- item-->
    <div class="dropdown-item noti-title">
      <h5>Notification (<?php echo e($notifications->count()); ?>)</h5>
    </div>
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="javascript:void(0);" class="dropdown-item notify-item <?php if($notification->is_read): ?> active <?php endif; ?> notificationItems"
         data-url="<?php echo e(route('admin.ajax.make.modal.as.read', $notification->id)); ?>"
         data-title="<?php echo e($notification->title); ?>"
         data-message="<?php echo e($notification->message); ?>">
        <?php if($notification->type == \App\Models\Notification::$types[0]): ?>
          <div class="notify-icon bg-success">
            <i class="mdi mdi-note"></i>
          </div>
        <?php elseif($notification->type == \App\Models\Notification::$types[1]): ?>
          <div class="notify-icon bg-warning">
            <i class="mdi mdi-account-alert"></i>
          </div>
        <?php else: ?>
          <div class="notify-icon bg-indigo-400">
            <i class="mdi mdi-information"></i>
          </div>
        <?php endif; ?>
        <p class="notify-details">
          <b title="<?php echo e($notification->title); ?>"><?php echo e($notification->title); ?></b>
          <small class="text-muted" title="<?php echo e($notification->message); ?>"><?php echo e(Str::limit($notification->message, 50)); ?></small>
        </p>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- All-->
    <a href="javascript:void(0);" class="dropdown-item notify-item">
      View All
    </a>
  </div>
</li>

<?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/components/notification.blade.php ENDPATH**/ ?>