

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-5">
        <div class="d-flex justify-content-center">
            <img height="300px"  width="500px" src="<?php echo e(asset('assets/frontend/img/error/e403g3.gif')); ?>" alt="">
        </div>
        <div class="mt-5">
            <h1 class="error-404-text">403 !!! <span class="text-dark">Forbidden ! Server Acess Denied</span></h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/errors/403.blade.php ENDPATH**/ ?>