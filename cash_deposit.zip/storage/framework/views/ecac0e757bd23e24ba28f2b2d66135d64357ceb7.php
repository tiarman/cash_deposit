

<?php $__env->startSection('stylesheet'); ?>
  <style>
    .mini-stat{
        -webkit-box-shadow: -6px 6px 15px 3px rgba(0,0,0,0.8);
        box-shadow: -6px 6px 15px 3px rgba(0,0,0,0.8);
    }
    .mini-stat:hover{
        -webkit-transform: translateY(-8px);
        transform: translateY(-8px);
        transition-duration: 0.5s;
    }
  </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">

    <div class="row">
      <div class="col-12">
        <?php if(\App\Helper\CustomHelper::canView('', 'Institute Head') && \App\Helper\CustomHelper::isInstituteTrainingProvider()): ?>
        <div class="card">
          <div class="card-body">
            <section class="panel">
              <header class="panel-heading">
                <h2 class="panel-title">Upcoming Training</h2>
              </header>
              <div class="panel-body">
                <?php if(session()->has('status')): ?>
                  <?php echo session()->get('status'); ?>

                <?php endif; ?>
                <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                       cellspacing="0" width="100%" style="font-size: 14px">
                  <thead>
                  <tr>
                    <th width="50">#</th>
                    <th>Training Title</th>
                    <th>Training Duration</th>
                    <th>Coordinator</th>
                    <th>Participants</th>
                  </tr>
                  </thead>
                  <tbody>


                  <?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                      <td class="p-1"><?php echo e(($key+1)); ?></td>
                      <td class="p-1 text-capitalize"><?php echo e($val->title); ?></td>
                      <td class="p-1"><?php echo e(\App\Helper\CustomHelper::dateDiffReadable($val->start_date, $val->end_date)); ?></td>
                      <td class="p-1 text-capitalize"><?php echo e($val->user->name_en); ?></td>
                      <td class="p-1 text-center"><?php echo e($val->members_count); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </section>
            <section class="panel">
              <header class="panel-heading">
                <h2 class="panel-title">Completed Training</h2>
              </header>
              <div class="panel-body">

                <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                       cellspacing="0" width="100%" style="font-size: 14px">
                  <thead>
                  <tr>
                    <th width="50">#</th>
                    <th>Training Title</th>
                    <th>Training Duration</th>
                    <th>Coordinator</th>
                    <th>Participants</th>
                  </tr>
                  </thead>
                  <tbody>


                  <?php $__currentLoopData = $complete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                      <td class="p-1"><?php echo e(($key+1)); ?></td>
                      <td class="p-1 text-capitalize"><?php echo e($val->title); ?></td>
                      <td class="p-1"><?php echo e(\App\Helper\CustomHelper::dateDiffReadable($val->start_date, $val->end_date)); ?></td>
                      <td class="p-1 text-capitalize"><?php echo e($val->user->name_en); ?></td>
                      <td class="p-1 text-center"><?php echo e($val->members_count); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
















































































































































































































































  </div><!-- container -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/admin/index.blade.php ENDPATH**/ ?>