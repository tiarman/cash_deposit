

<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


                        <header class="panel-heading">
                            <h2 class="panel-title">Transaction History</h2>
                        </header>
                        <div class="main-content">

                            <div class="page-content">
                                <div class="container-fluid">

                                    <div class="row">
                                        <div class="col-md-6 col-xl-6">


                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mini-stat clearfix">
                                                        <span class="mini-stat-icon bg-pink float-start"><i class="mdi mdi-currency-usd"></i></span>
                                                        <div class="mini-stat-info text-end">
                                                            <span class="counter text-pink">Withdraw Total</span>
                                                            <?php
                                                            $total = 0;
                                                            foreach ($total_withdraw as $item) {
                                                                $total += intval($item->amount);
                                                            }
                                                            ?>
                                                            <strong style="font-size: 18px">Total: <?php echo e($total ?? " "); ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mini-stat clearfix">
                                                        <span class="mini-stat-icon bg-success float-start"><i class="mdi mdi-currency-usd"></i></span>
                                                        <div class="mini-stat-info text-end">
                                                            <span class="counter text-success">Deposit Total</span>
                                                            <?php
                                                            $total = 0;
                                                            foreach ($total_deposits as $item) {
                                                                $total += intval($item->amount);
                                                            }
                                                            ?>
                                                            <strong style="font-size: 18px">Total: <?php echo e($total ?? " "); ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mini-stat">
                                                        <span class="mini-stat-icon bg-primary float-start"><i class="mdi mdi-currency-usd"></i></span>
                                                        <div class="mini-stat-info text-end">
                                                            <?php
                                                            // total total calculate
                                                            $totalDeposit = 0;
                                                            foreach ($total_deposits as $item) {
                                                                $totalDeposit += intval($item->amount);
                                                            }
                                                            // total withdraw calculate
                                                            $totalWithdraw = 0;
                                                            foreach ($total_withdraw as $item) {
                                                                $totalWithdraw += intval($item->amount);
                                                            }
                                                            // total interest calculate
                                                            $totalInterest = 0;
                                                            foreach ($interest as $key => $value) {
                                                                $totalInterest += intval($value->interest_amount);
                                                            }

                                                            ?>
                                                            <span class="counter text-primary">Curent Balance</span>
                                                            <strong style="font-size: 18px"> Total: <?php echo e(($totalDeposit + $totalInterest) - $totalWithdraw ?? " "); ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mini-stat">
                                                        <span class="mini-stat-icon bg-primary float-start"><i class="mdi mdi-currency-usd"></i></span>
                                                        <div class="mini-stat-info text-end">
                                                            <span class="counter text-primary">Interest</span>
                                                            <strong>Total: <?php echo e($totalInterest); ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                        </div>







    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">Transaction History</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>

                            
                                <div class="table-rep-plugin">
                                    <div class="table-responsive mb-0" data-bs-pattern="priority-columns">
                                        <table id="datatable-buttons" class="table table-striped table-bordered nowrap" cellspacing="0" width="100%" style="font-size: 14px">



                                    <thead>
                                    <tr>

                                        <th>Transaction Type</th>
                                        <th>Transaction Status</th>
                                        <th>Mobile/AC Number</th>
                                        <th>Amount</th>
                                        <th>Transaction ID</th>
                                        <th>Date</th>
                                        <th>Status</th>

                                        <?php if(\App\Helper\CustomHelper::canView('Manage User|Delete User', 'Super Admin')): ?>
                                            <th class="hidden-phone" width="40">Option</th>
                                        <?php endif; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $wid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                                            <td class="p-1 text-capitalize"><?php echo e($val->transaction_type); ?></td>
                                            <td class="p-1 text-capitalize">Withdraw</td>
                                            <td class="p-1 text-capitalize"><?php echo e($val->withdraw_id); ?></td>
                                            <td class="p-1"><?php echo e($val->amount); ?></td>
                                            <td class="p-1"></td>
                                            <td width="200" class="p-1"><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>
                                            <td class="p-1 text-capitalize "><button class="btn text-capitalize <?php if($val->status == 'pending'): ?> btn-warning <?php else: ?> btn-success <?php endif; ?>"><?php echo e($val->status); ?></button></td>
                                        </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $allDeposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                                            <td class="p-1 text-capitalize"><?php echo e($vals->transaction_type); ?></td>
                                            <td class="p-1 text-capitalize">Deposit</td>
                                            <td class="p-1 text-capitalize"><?php echo e($vals->payment_no); ?></td>
                                            <td class="p-1"><?php echo e($vals->amount); ?></td>
                                            <td class="p-1"><?php echo e($vals->transaction_id); ?></td>
                                            <td width="200" class="p-1"><?php echo e(date('F d, Y h:i A', strtotime($vals->created_at))); ?></td>
                                            <td class="p-1 text-capitalize "><button class="btn text-capitalize <?php if($vals->status == 'pending'): ?> btn-warning <?php else: ?> btn-success <?php endif; ?>"><?php echo e($vals->status); ?></button></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <thead>
                                    <tr>
                                        <td></td>
                                        <td></td>

                                        <td></td>
                                        <td></td>
                                        <td></td>

                                        
                                        <td></td>
                                        <td></td>

                                    </tr>
                                    </thead>
                                    </tbody>
                                </table>
                                    </div>
                                </div>
                            <div class="row">

                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="userDeleteModal" tabindex="-1" role="dialog" aria-labelledby="userDeleteModal"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Delete Sub Agents</h4>
                </div>
                <div class="modal-body">
                    <strong>Are you sure to delete this Transaction?</strong>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-success btn-sm yes-btn">Yes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(document).ready(function () {
            // $('#datatable-buttons').DataTable();

            var table = $('#datatable-buttons').DataTable({
              lengthChange: false,
              buttons: ['copy', 'excel', 'pdf']
                // buttons: ['copy', 'excel', 'pdf', 'colvis']
            });

            table.buttons().container()
              .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/admin/cash/transaction.blade.php ENDPATH**/ ?>