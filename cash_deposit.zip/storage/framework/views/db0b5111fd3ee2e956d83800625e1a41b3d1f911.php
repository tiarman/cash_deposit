

<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">Deposit</h2>
                        </header>

                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>

                            <div class="row">
                                <?php $__currentLoopData = $payment_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-lg-3">
                                        <div class="product-list-box">
                                            <a href="" data-bs-toggle="modal"
                                                data-bs-target="#<?php echo e($item?->name_key); ?>" data-bs-whatever="@mdo">
                                                <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid"
                                                    alt="work-thumbnail">
                                            </a>
                                            <div class="detail">
                                                <h4 class="font-16 text-center"><a href=""
                                                        class="text-dark"><?php echo e(ucfirst($item?->name)); ?></a> </h4>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <header class="panel-heading">
                                <h2 class="panel-title">Deposit List</h2>
                            </header>
                            <?php
                            $total = 0;
                            foreach ($total_deposits as $item) {
                                $total += intval($item->amount);
                            }
                            ?>
                            <h1 class="btn btn-primary mb-3 fw-bold">Total Deposit: <?php echo e($total); ?></h1>
                            <div class="panel-body">
                                <?php if(session()->has('status')): ?>
                                    <?php echo session()->get('status'); ?>

                                <?php endif; ?>

                                <?php if(\App\Helper\CustomHelper::canView('Create Sub Agent', 'Super Admin|Agent')): ?>
                                <?php endif; ?>
                                    <div class="table-rep-plugin">
                                        <div class="table-responsive mb-0" data-bs-pattern="priority-columns">
                                            <table id="datatable-buttons" class="table table-striped table-bordered nowrap" cellspacing="0" width="100%" style="font-size: 14px">

                                    <thead>
                                        <tr>
                                            <th width="10">#</th>
                                            <th>Date</th>
                                            <th>Transaction Type</th>
                                            <th>Transaction ID</th>
                                            <th>Payment Number</th>
                                            <th>Amount</th>
                                            
                                            <th>Status</th>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="<?php if($key % 2 == 0): ?> gradeX <?php else: ?> gradeC <?php endif; ?>">
                                                <td class="p-1"><?php echo e($key + 1); ?></td>
                                                <td width="200" class="p-1">
                                                    <?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>
                                                <td class="p-1 text-capitalize"><?php echo e($val->transaction_type); ?></td>
                                                <td class="p-1 text-capitalize"><?php echo e($val->transaction_id); ?></td>
                                                <td class="p-1 text-capitalize"><?php echo e($val->payment_no); ?></td>
                                                <td class="p-1"><?php echo e($val->amount); ?></td>
                                                
                                                
                                                
                                                


                                                <td class="p-1 text-capitalize "><button
                                                        class="btn text-capitalize <?php if($val->status == 'pending'): ?> btn-warning <?php else: ?> btn-success <?php endif; ?>"><?php echo e($val->status); ?></button>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                        </div>
                                    </div>
                            </div>

                            <?php $__currentLoopData = $payment_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="modal fade" id="<?php echo e($item?->name_key); ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">
                                                    <strong><?php echo e(ucfirst($item?->name)); ?></strong>
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('admin.deposit')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="control-label">Transaction Type<span
                                                                        class="text-danger">*</span></label>
                                                                <select name="transaction_type"
                                                                    class="form-control <?php $__errorArgs = ['transaction_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                    <option value="<?php echo e(ucfirst($item?->name)); ?>">
                                                                        <?php echo e(ucfirst($item?->name)); ?></option>
                                                                    /
                                                                </select>
                                                                <?php $__errorArgs = ['transaction_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <strong
                                                                        class="text-danger"><?php echo e($errors->first('transaction_type')); ?></strong>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <strong class="text-danger" id="name_error"></strong>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="control-label">Payment No<span
                                                                        class="text-danger">*</span></label>
                                                                <select name="payment_no"
                                                                    class="form-control <?php $__errorArgs = ['payment_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                    <option value="">Choose a Payment Number</option>
                                                                    <?php $__currentLoopData = $item->numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($num->number); ?>"
                                                                            <?php if(old('mobile') == $num->mobile): ?> selected <?php endif; ?>>
                                                                            <?php echo e(ucfirst($num->number)); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <?php $__errorArgs = ['payment_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <strong
                                                                        class="text-danger"><?php echo e($errors->first('payment_no')); ?></strong>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <strong class="text-danger" id="payment_no_error"></strong>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="control-label">Transaction Number<span
                                                                        class="text-danger">*</span></label>
                                                                <input type="text" name="transaction_id"
                                                                    placeholder="TRX Number" autocomplete="off" required
                                                                    value="<?php echo e(old('transaction_id')); ?>"
                                                                    class="form-control <?php $__errorArgs = ['transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                <?php $__errorArgs = ['transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <strong
                                                                        class="text-danger"><?php echo e($errors->first('transaction_id')); ?></strong>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="control-label">Amount<span
                                                                        class="text-danger">*</span></label>
                                                                <input type="number" name="amount" placeholder="00"
                                                                    autocomplete="off" required
                                                                    value="<?php echo e(old('amount')); ?>"
                                                                    class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <strong
                                                                        class="text-danger"><?php echo e($errors->first('amount')); ?></strong>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <button type="submit" class="btn btn-success">Submit</button>
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#datatable-buttons').DataTable();

            // var table = $('#datatable-buttons').DataTable({
            //   lengthChange: false,
            //   buttons: ['copy', 'excel', 'pdf', 'colvis']
            // });
            //
            // table.buttons().container()
            //   .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');


            $(document).on('change', 'input[name="onoffswitch3"]', function() {
                console.log('ttttt')
                var status = 'pending';
                var id = $(this).data('id')
                var isChecked = $(this).is(":checked");
                if (isChecked) {
                    status = 'accepted';
                }
                $.ajax({
                    url: "<?php echo e(route('admin.ajax.update.deposit.status')); ?>",
                    method: "post",
                    dataType: "html",
                    data: {
                        'id': id,
                        'status': status
                    },
                    success: function(data) {
                        if (data === "success") {}
                    }
                });
            })


            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            //
            // 
            // 
            // 
            // 
            // 
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/admin/cash/deposit.blade.php ENDPATH**/ ?>