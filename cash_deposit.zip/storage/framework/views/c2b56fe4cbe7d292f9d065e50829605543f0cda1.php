<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\All Projects\personal_projects\cash_deposit\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>