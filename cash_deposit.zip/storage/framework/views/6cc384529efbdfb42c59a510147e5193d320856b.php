<?php echo e($slot); ?>

<?php /**PATH C:\All Projects\personal_projects\cash_deposit\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>