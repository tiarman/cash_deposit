<img style="background: whitesmoke;display: unset;height: 60px"
     src="<?php echo e($c_logo ? asset($c_logo) : auth()->user()->profile_photo_url); ?>"
     height="100"
     alt="logo">
<?php /**PATH C:\All Projects\personal_projects\cash_deposit\resources\views/components/admin-sidebar-logo.blade.php ENDPATH**/ ?>